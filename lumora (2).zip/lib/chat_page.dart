import 'dart:convert';
import 'dart:io' show Platform;
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'api.dart';
import 'main.dart';
import 'mcp.dart';
import 'oauth.dart';
import 'router.dart';
import 'pages.dart';
import 'settings.dart';
import 'projects.dart';
import 'ui.dart';
import 'store.dart';
import 'web.dart';
import 'intent.dart';

const modes = {
  'Chat': "You are Lumora, a helpful assistant. Reply in the user's language.",
  'Cowork':
      "You are Lumora in Cowork mode: plan tasks step by step and help get work done. Reply in the user's language.",
  'Agent': agentPrompt,
  'Code':
      "You are Lumora in Code mode: write clean, correct code with brief explanations. Reply in the user's language.",
};
const agentPrompt =
    "You are Lumora in Agent mode: break the goal into steps, use the available tools repeatedly until the task is done, then summarize what you did. Reply in the user's language.";
const efforts = ['auto', 'low', 'medium', 'high'];

class ChatPage extends StatefulWidget {
  const ChatPage({super.key});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  Chat chat = _fresh();
  final input = TextEditingController();
  final scroll = ScrollController();
  final stt = SpeechToText();
  final tts = FlutterTts();
  List<String> models = [];
  String? model; // null = Auto
  String mode = 'Chat', effort = 'auto', query = '';
  String get lang => Prefs.voiceLang;
  set lang(String v) => Prefs.voiceLang = v;
  bool busy = false, live = false, listening = false, cancel = false;
  int _lastUi = 0;
  final _bad = <String, int>{};
  final _rc = <String, (Pick, int)>{};
  List<String> pendImgs = [];
  String? imageModel;
  bool webOn = false, deepOn = false, imageOn = false;
  String imageSize = '1024x1024';
  final _imgCache = <String, Uint8List>{};
  String pendText = '';

  String mcpNote = '';
  final _tc = <String, List<Map<String, dynamic>>>{};
  final _cl = <String, McpClient>{};

  Future<(List<Map<String, dynamic>>, Map<String, (McpClient, String)>)>
      mcpTools() async {
    final tools = <Map<String, dynamic>>[];
    final map = <String, (McpClient, String)>{};
    mcpNote = '';
    if (!Prefs.useTools) return (tools, map);
    var n = 0;
    for (final s in Store.mcps.where((s) => s['on'] == true)) {
      n++;
      try {
        final tok = await OAuth.token(s);
        final c = _cl.putIfAbsent(s['url'], () => McpClient(s['url'], tok));
        c.token = tok;
        if (!_tc.containsKey(s['url'])) {
          await c.init();
          _tc[s['url']] = await c.tools();
        }
        for (final t in _tc[s['url']]!) {
          var nm = 's${n}_${t['name']}'.replaceAll(RegExp(r'[^a-zA-Z0-9_-]'), '_');
          if (nm.length > 64) nm = nm.substring(0, 64);
          map[nm] = (c, t['name'].toString());
          tools.add({
            'type': 'function',
            'function': {
              'name': nm,
              'description': (t['description'] ?? '').toString(),
              'parameters':
                  t['inputSchema'] ?? {'type': 'object', 'properties': {}}
            }
          });
        }
      } catch (err) {
        mcpNote += "MCP '${s['name']}': ${Api.explain(err)}\n";
      }
    }
    return (tools, map);
  }

  Future<void> runTools(
      String m,
      List<Map<String, dynamic>> hist,
      String? e,
      List<Map<String, dynamic>> tools,
      Map<String, (McpClient, String)> tmap,
      Msg reply) async {
    final h = List<Map<String, dynamic>>.from(hist);
    Api.lastIn = Api.lastOut = 0;
    var trace = '';
    for (var i = 0; i < (mode == 'Agent' ? 12 : 6); i++) {
      if (cancel) break;
      final msg = await Api.chatOnce(m, h, e, tools);
      final calls = (msg['tool_calls'] as List?) ?? [];
      if (calls.isEmpty) {
        setState(() => reply.text = trace + (msg['content'] ?? '').toString());
        return;
      }
      h.add({
        'role': 'assistant',
        'content': msg['content'],
        'tool_calls': calls
      });
      for (final c in calls) {
        final fn = c['function'];
        final name = fn['name'] as String;
        trace += '▸ ${tmap[name]?.$2 ?? name}\n';
        setState(() => reply.text = '$trace…');
        String out;
        try {
          Map args = {};
          try {
            args = jsonDecode(fn['arguments'] ?? '{}');
          } catch (_) {}
          out = await tmap[name]!.$1.call(tmap[name]!.$2, args);
        } catch (err) {
          out = 'Tool error: $err';
        }
        h.add({'role': 'tool', 'tool_call_id': c['id'], 'content': out});
      }
    }
    setState(() => reply.text = 'Stopped after too many tool steps.');
  }

  static Chat _fresh() =>
      Chat(DateTime.now().millisecondsSinceEpoch.toString(), 'New chat', []);

  @override
  void initState() {
    super.initState();
    loadPrefs().then((_) => loadModels());
  }

  Future<void> loadPrefs() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      model = p.getString('m_model');
      final md = p.getString('m_mode');
      mode = 'Chat';
      effort = p.getString('m_effort') ?? 'auto';
    });
  }

  Future<void> savePrefs() async {
    final p = await SharedPreferences.getInstance();
    model == null ? await p.remove('m_model') : await p.setString('m_model', model!);
    await p.setString('m_mode', mode);
    await p.setString('m_effort', effort);
    await p.setString('m_lang', lang);
  }

  Future<void> loadModels() async {
    if (!Api.ready) return;
    if (models.isEmpty && Api.cached.isNotEmpty) {
      setState(() => models = Api.cached);
    }
    try {
      final m = await Api.models();
      if (mounted) {
        setState(() {
          models = m;
          if (model != null && !m.contains(model)) model = null;
        });
      }
    } catch (e) {
      if (mounted) snack('API check failed: ${Api.explain(e)}');
    }
  }

  void snack(String s) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));

  List<String> order(bool big) {
    if (model != null) return [model!, ...models.where((m) => m != model)];
    final re = RegExp(big
        ? r'opus|sonnet|pro|gpt-5|o3|large'
        : r'haiku|flash|mini|lite|small');
    final pref = models.where((m) => re.hasMatch(m.toLowerCase())).toList();
    return [...pref, ...models.where((m) => !pref.contains(m))];
  }

  Future<void> send([String? voice]) async {
    final t = (voice ?? input.text).trim();
    if ((t.isEmpty && pendImgs.isEmpty && pendText.isEmpty) || busy) return;
    if (!Api.ready || models.isEmpty) {
      snack('Add your API key in the menu first.');
      return;
    }
    if (imageOn) {
      if (t.isEmpty) {
        snack('Write what image to create.');
        return;
      }
      input.clear();
      await runImage(t);
      return;
    }
    var autoDeep = false, autoWeb = false;
    if (Prefs.autoIntent && !imageOn && pendImgs.isEmpty && t.isNotEmpty) {
      final it = Intents.detect(t, imageModels: true);
      if (it == Intent.image) {
        input.clear();
        await runImage(t);
        return;
      }
      autoDeep = it == Intent.deep;
      autoWeb = it == Intent.web;
    }
    if (Store.limit > 0 &&
        (Store.monthly[DateTime.now().toIso8601String().substring(0, 7)] ?? 0) >=
            Store.limit) {
      snack('Monthly token limit reached. Change it in User Dashboard.');
      return;
    }
    final full = pendText.isEmpty ? t : '$t\n\n---\n$pendText';
    final deep = deepOn || autoDeep;
    final web = webOn || deep || autoWeb;
    final recent = [
      for (final m in chat.msgs.reversed.take(4).toList().reversed)
        '${m.user ? 'User' : 'Assistant'}: ${m.text.length > 300 ? m.text.substring(0, 300) : m.text}'
    ];
    final hadImg =
        pendImgs.isNotEmpty || chat.msgs.any((m) => m.user && m.images.isNotEmpty);
    final reply = Msg(false, '');
    final past = chat.msgs.length > 40
        ? chat.msgs.sublist(chat.msgs.length - 40)
        : List<Msg>.of(chat.msgs);
    if (past.isNotEmpty && !past.first.user) past.removeAt(0);
    final hist = <Map<String, dynamic>>[
      {
        'role': 'system',
        'content': modes[mode]! +
            projectCtx() +
            (Prefs.name.isEmpty ? '' : '\n\nThe user\'s name is ${Prefs.name}.') +
            (Store.persona.isEmpty ? '' : '\n\nPersona: ${Store.persona}') +
            (Store.notes.isEmpty
                ? ''
                : '\n\nThings to remember about the user:\n${Store.notes}')
      },
      for (final m in past.where((m) => !m.err))
        {
          'role': m.user ? 'user' : 'assistant',
          'content': (m.images.isEmpty || !m.user)
              ? m.text
              : [
                  {'type': 'text', 'text': m.text},
                  for (final i in m.images)
                    {'type': 'image_url', 'image_url': {'url': i}}
                ]
        },
      {
        'role': 'user',
        'content': pendImgs.isEmpty
            ? full
            : [
                {'type': 'text', 'text': full},
                for (final i in pendImgs)
                  {'type': 'image_url', 'image_url': {'url': i}}
              ]
      },
    ];
    setState(() {
      chat.msgs
        ..add(Msg(true, full, List.of(pendImgs)))
        ..add(reply);
      if (chat.title == 'New chat') {
        final tt = t.isEmpty ? 'Attachment' : t;
        chat.title = tt.length > 30 ? tt.substring(0, 30) : tt;
      }
      chat.mode = mode;
      chat.ts = DateTime.now().millisecondsSinceEpoch;
      if (!Store.chats.contains(chat)) Store.chats.insert(0, chat);
      busy = true;
      deepOn = false;
    });
    if (Prefs.haptics) HapticFeedback.lightImpact();
    input.clear();
    pendImgs = [];
    pendText = '';
    final (tools, tmap) = await mcpTools();
    final task0 = AutoRouter.classify(full, mode, tools.isNotEmpty, hadImg);
    final task = deep ? Task(task0.kind, 2, task0.vision, task0.tools) : task0;
    final smart =
        model == null && (task.cx > 0 || task.vision || tools.isNotEmpty);
    if (smart) setState(() => reply.note = 'Choosing the best model…');
    final pickR =
        smart ? await smartPick(task, full) : AutoRouter.pick(models, task, _bad);
    final o = model != null
        ? [model!, ...pickR.order.where((x) => x != model)]
        : pickR.order;
    var srcs = <Hit>[];
    var webNote = '';
    if (web) {
      void say(String s) {
        if (mounted) setState(() => reply.text = s);
      }

      try {
        final q = t.isEmpty ? full : t;
        final String intro;
        if (deep) {
          srcs = await Web.deep(q, o.first, say);
          intro = Web.deepIntro();
        } else {
          final sq = await Web.query(o.first, recent, q);
          srcs = await Web.quick(sq, say);
          intro = Web.webIntro();
        }
        final aug = '$intro\n\n${Web.context(srcs)}\nUser request: $full';
        final lm = hist.last;
        if (lm['content'] is String) {
          lm['content'] = aug;
        } else {
          (lm['content'] as List)[0] = <String, dynamic>{'type': 'text', 'text': aug};
        }
      } catch (e) {
        srcs = [];
        webNote = 'Web search failed (${Api.explain(e)}). Answered without it.';
      }
    }
    final lv = ['low', 'medium', 'high'][task.cx];
    final String? eff = effort != 'auto'
        ? effort
        : (model == null
            ? pickR.effort
            : (AutoRouter.profile(model!).reason ? lv : null));
    final tries = <(String, String?, bool)>[
      (o.first, eff, true),
      if (eff != null) (o.first, null, true),
      if (tools.isNotEmpty) (o.first, null, false),
      if (o.length > 1) (o[1], null, false),
      if (o.length > 2) (o[2], null, false),
    ];
    String used = o.first;
    for (final (m, e, useT) in tries) {
      try {
        used = m;
        if (!useT && tools.isNotEmpty && mcpNote.isEmpty) {
          mcpNote = 'This model or server rejected tool use, so it answered without tools.';
        }
        reply.text = '';
        if (useT && tools.isNotEmpty) {
          await runTools(m, hist, e, tools, tmap, reply);
        } else {
          await for (final c in Api.chat(m, hist, e)) {
            if (cancel) break;
            reply.text += c;
            final now = DateTime.now().millisecondsSinceEpoch;
            if (now - _lastUi > 60) {
              _lastUi = now;
              setState(() {});
              if (scroll.hasClients) {
                scroll.jumpTo(scroll.position.maxScrollExtent);
              }
            }
          }
        }
        break;
      } catch (err) {
        reply.text = 'Error: $err';
        if (e == null && (!useT || tools.isEmpty)) {
          _bad[m] = DateTime.now().millisecondsSinceEpoch;
        }
      }
    }
    if (model == null) {
      reply.note =
          'Auto → $used · ${pickR.why}${eff != null ? ' · effort $eff' : ''}';
    }
    cancel = false;
    if (mounted) setState(() {});
    if (reply.text.isEmpty) reply.text = '(stopped)';
    final ok = !reply.text.startsWith('Error: ');
    if (mcpNote.isNotEmpty && ok) {
      setState(() => reply.text = '⚠ ${mcpNote.trim()}\n\n${reply.text}');
    }
    if (ok && webNote.isNotEmpty) {
      setState(() => reply.text = '⚠ $webNote\n\n${reply.text}');
    }
    if (ok && srcs.isNotEmpty) {
      setState(() => reply.text += '\n\n## Sources\n${Web.sourcesList(srcs)}');
    }
    if (ok) {
      Store.addUsage(
          used,
          Api.lastIn > 0 ? Api.lastIn : full.length ~/ 4,
          Api.lastOut > 0 ? Api.lastOut : reply.text.length ~/ 4);
    } else {
      reply.err = true;
      setState(() => reply.text = Api.friendly(reply.text, used));
    }
    await Store.save();
    if (mounted) setState(() => busy = false);
    if (live) {
      ok ? tts.speak(reply.text.replaceAll(RegExp(r'[*#`_]'), '')) : liveListen();
    }
  }

  Future<void> attach() async {
    final r = await FilePicker.platform.pickFiles(withData: true);
    if (r == null || r.files.single.bytes == null) return;
    final f = r.files.single;
    final ext = (f.extension ?? '').toLowerCase();
    if (['png', 'jpg', 'jpeg', 'webp'].contains(ext)) {
      pendImgs.add(
          'data:image/${ext == 'jpg' ? 'jpeg' : ext};base64,${base64Encode(f.bytes!)}');
    } else {
      pendText += '[${f.name}]\n${utf8.decode(f.bytes!, allowMalformed: true)}\n';
    }
    setState(() {});
  }


  // ------------------------------------------------- Camera + image creation
  Future<void> takePhoto() async {
    if (!(Platform.isAndroid || Platform.isIOS)) {
      snack('The camera is only available on phones.');
      return;
    }
    try {
      final x = await ImagePicker().pickImage(
          source: ImageSource.camera,
          maxWidth: 1600,
          maxHeight: 1600,
          imageQuality: 82);
      if (x == null) return;
      final b = await x.readAsBytes();
      pendImgs.add('data:image/jpeg;base64,${base64Encode(b)}');
      if (mounted) setState(() {});
      snack('Photo added. Write a question and send.');
    } catch (e) {
      snack('Camera error: $e');
    }
  }

  Uint8List imgBytes(String i) {
    final k =
        '${i.length}${i.substring(i.length - 48)}${i.substring(i.length ~/ 2, i.length ~/ 2 + 48)}';
    return _imgCache.putIfAbsent(
        k, () => base64Decode(i.substring(i.indexOf(',') + 1)));
  }

  Future<void> saveImage(String i) async {
    final ext = i.startsWith('data:image/jpeg')
        ? 'jpg'
        : (i.startsWith('data:image/webp') ? 'webp' : 'png');
    try {
      final p = await FilePicker.platform.saveFile(
          fileName: 'lumora_${DateTime.now().millisecondsSinceEpoch}.$ext',
          bytes: imgBytes(i));
      if (p != null) snack('Saved.');
    } catch (e) {
      snack('Save failed: $e');
    }
  }

  void viewImage(String i) => Navigator.push(
      context,
      MaterialPageRoute(
          builder: (_) => Scaffold(
              backgroundColor: Colors.black,
              appBar: AppBar(
                  backgroundColor: Colors.black,
                  foregroundColor: Colors.white,
                  actions: [
                    IconButton(
                        tooltip: 'Save',
                        icon: const Icon(Icons.download),
                        onPressed: () => saveImage(i)),
                  ]),
              body: Center(
                  child: InteractiveViewer(
                      maxScale: 6, child: Image.memory(imgBytes(i)))))));

  Widget imgStrip(Msg m, {double w = 300}) => Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Wrap(spacing: 8, runSpacing: 8, children: [
        for (final i in m.images)
          GestureDetector(
              onTap: () => viewImage(i),
              child: ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: Image.memory(imgBytes(i),
                      width: w,
                      fit: BoxFit.cover,
                      gaplessPlayback: true,
                      errorBuilder: (_, __, ___) => Container(
                          width: 120,
                          height: 80,
                          color: soft,
                          child: const Icon(Icons.broken_image_outlined))))),
      ]));

  static const _free = '__free';

  List<String> get _imgList => [
        ...models.where(Api.isImageModel),
        ...models.where((m) => !Api.isImageModel(m)),
      ];

  String get imageLabel {
    final m = _imgModel();
    return m == _free ? 'Free service' : m;
  }

  /// The chosen image model, or the first image-named model on the server,
  /// or the free service when the server has none.
  String _imgModel() {
    if (imageModel != null && (imageModel == _free || models.contains(imageModel))) {
      return imageModel!;
    }
    for (final m in models) {
      if (Api.isImageModel(m)) return m;
    }
    return _free;
  }

  Future<String> _imgPrompt(String p) async {
    final m = AutoRouter.routerModel(models, _bad);
    if (m == null) return p;
    try {
      final r = await Api.complete(
          m,
          'Rewrite the user\'s request as one vivid, detailed English prompt for an AI image generator (subject, style, lighting, composition, quality). Max 60 words. Output only the prompt.',
          p,
          maxTokens: 150,
          secs: 25);
      final t = r.trim().replaceAll('"', '');
      return t.isEmpty ? p : t;
    } catch (_) {
      return p;
    }
  }

  /// Model + size settings for image creation (opened from the chip).
  Future<void> imageOptions() async {
    final list = _imgList;
    if (list.isEmpty) {
      snack('Add your API key first.');
      return;
    }
    final hasImg = models.any(Api.isImageModel);
    var m = _imgModel();
    var size = imageSize;
    final ok = await showDialog<bool>(
        context: context,
        builder: (_) => StatefulBuilder(
            builder: (ctx, set) => AlertDialog(
                  backgroundColor: bg,
                  title: const Text('Image settings'),
                  content: SingleChildScrollView(
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                    if (!hasImg)
                      const Padding(
                          padding: EdgeInsets.only(bottom: 12),
                          child: Text(
                              'Your server has no model with "image" in its name, so the free service is used. Pick another one only if you know it can create images.',
                              style: TextStyle(fontSize: 12.5, color: Colors.black54))),
                    DropdownButtonFormField<String>(
                        value: m,
                        isExpanded: true,
                        decoration: const InputDecoration(labelText: 'Model'),
                        items: [
                          const DropdownMenuItem(
                              value: _free,
                              child: Text('Free service (no key, small images)')),
                          for (final x in list)
                            DropdownMenuItem(
                                value: x,
                                child: Text(x, overflow: TextOverflow.ellipsis))
                        ],
                        onChanged: (v) => set(() => m = v ?? m)),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                        value: size,
                        decoration: const InputDecoration(labelText: 'Size'),
                        items: const [
                          DropdownMenuItem(
                              value: '1024x1024', child: Text('Square 1024×1024')),
                          DropdownMenuItem(
                              value: '1024x1536', child: Text('Portrait 1024×1536')),
                          DropdownMenuItem(
                              value: '1536x1024', child: Text('Landscape 1536×1024')),
                          DropdownMenuItem(
                              value: 'default', child: Text('Model default')),
                        ],
                        onChanged: (v) => set(() => size = v ?? size)),
                  ])),
                  actions: [
                    TextButton(
                        onPressed: () => Navigator.pop(ctx, false),
                        child: const Text('Cancel')),
                    FilledButton(
                        style: FilledButton.styleFrom(backgroundColor: accent),
                        onPressed: () => Navigator.pop(ctx, true),
                        child: const Text('Save')),
                  ],
                )));
    if (ok == true) {
      setState(() {
        imageModel = m;
        imageSize = size;
      });
    }
  }

  void toggleImage() {
    setState(() {
      imageOn = !imageOn;
      if (imageOn) deepOn = false;
    });
    if (imageOn) {
      snack(models.any(Api.isImageModel)
          ? 'Create image is on. Type what you want and send.'
          : 'Create image is on. No image model found: tap the chip to pick one.');
    }
  }

  /// Creates an image from [prompt] and adds it to the chat.
  Future<void> runImage(String prompt) async {
    if (busy) return;
    final m = _imgModel();
    final size = imageSize;
    final reply = Msg(false, 'Creating image…');
    setState(() {
      chat.msgs
        ..add(Msg(true, '🎨 $prompt'))
        ..add(reply);
      if (chat.title == 'New chat') {
        chat.title = prompt.length > 30 ? prompt.substring(0, 30) : prompt;
      }
      chat.mode = mode;
      chat.ts = DateTime.now().millisecondsSinceEpoch;
      if (!Store.chats.contains(chat)) Store.chats.insert(0, chat);
      busy = true;
    });
    if (scroll.hasClients) scroll.jumpTo(scroll.position.maxScrollExtent);
    String? serverErr;
    if (m != _free) {
      try {
        reply.images = await Api.generateImage(m, prompt, size: size);
        reply.text = 'Image created with $m. Tap it to view or save.';
      } catch (e) {
        serverErr = e.toString().replaceFirst('Exception: ', '');
      }
    }
    if (reply.images.isEmpty) {
      try {
        if (mounted) setState(() => reply.text = 'Creating image with the free service…');
        final ep = await _imgPrompt(prompt);
        reply.images = [await Api.freeImage(ep, size)];
        reply.text = serverErr == null
            ? 'Image created with the free service. Tap it to view or save.'
            : 'Your server model ($m) could not create it, so the free service was used. Tap the image to view or save.';
      } catch (e) {
        reply.err = true;
        reply.text =
            'Could not create the image.\n\n${serverErr == null ? '' : 'Server ($m):\n$serverErr\n\n'}Free service: ${e.toString().replaceFirst('Exception: ', '')}';
      }
    }
    await Store.save();
    if (mounted) setState(() => busy = false);
    if (scroll.hasClients) scroll.jumpTo(scroll.position.maxScrollExtent);
  }

  Future<bool> sttInit() =>
      stt.initialize(onError: (e) => snack('Speech: ${e.errorMsg}'));

  Future<String?> loc() async {
    final ls = (await stt.locales()).map((l) => l.localeId).toList();
    final norm = lang.toLowerCase();
    for (final l in ls) {
      if (l.toLowerCase().replaceAll('-', '_') == norm) return l;
    }
    final pre = lang.startsWith('bn') ? 'bn' : 'en';
    for (final l in ls) {
      if (l.toLowerCase().startsWith(pre)) return l;
    }
    if (lang.startsWith('bn')) {
      snack('Bengali speech recognition not found on this phone. Install Bengali in Google app/keyboard voice settings.');
    }
    return null;
  }

  Future<void> setupTts() async {
    await tts.setSpeechRate(Prefs.voiceRate);
    final want = lang.startsWith('bn') ? ['bn-BD', 'bn-IN', 'bn'] : ['en-US'];
    for (final l in want) {
      if (await tts.isLanguageAvailable(l) == true) {
        await tts.setLanguage(l);
        return;
      }
    }
    snack(lang.startsWith('bn')
        ? 'Bengali voice not installed. Phone Settings > Text-to-speech > Google > install Bengali voice data.'
        : 'Voice not available.');
  }

  Future<void> mic() async {
    if (listening) {
      await stt.stop();
      setState(() => listening = false);
      return;
    }
    if (!await sttInit()) {
      snack('Speech recognition is not available.');
      return;
    }
    setState(() => listening = true);
    stt.listen(
        localeId: await loc(),
        onResult: (r) {
          input.text = r.recognizedWords;
          if (r.finalResult && mounted) setState(() => listening = false);
        });
  }

  Future<void> toggleLive() async {
    if (live) {
      live = false;
      await tts.stop();
      await stt.stop();
      setState(() {});
      return;
    }
    if (!await sttInit()) {
      snack('Speech recognition is not available.');
      return;
    }
    await setupTts();
    tts.setCompletionHandler(() {
      if (live) liveListen();
    });
    setState(() => live = true);
    liveListen();
  }

  Future<void> liveListen() async {
    if (!live || busy) return;
    stt.listen(
        localeId: await loc(),
        pauseFor: const Duration(seconds: 2),
        onResult: (r) {
          if (!r.finalResult) return;
          r.recognizedWords.trim().isEmpty ? liveListen() : send(r.recognizedWords);
        });
  }

  void toolsSheet() => showModalBottomSheet(
      context: context,
      backgroundColor: bg,
      builder: (_) => SafeArea(
            child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
              _opt(Icons.brush_outlined, 'Create image',
                  'Type what you want, send to get an image', imageOn, toggleImage),
              _opt(Icons.travel_explore, 'Deep research',
                  'Many searches, reads sources, writes a cited report', deepOn, () {
                setState(() {
                  deepOn = !deepOn;
                  if (deepOn) imageOn = false;
                });
                if (deepOn) snack('Deep research is on for your next message. It can take a minute.');
              }),
              _opt(Icons.public, 'Web search', 'Answer using live web results',
                  webOn, () {
                setState(() {
                  webOn = !webOn;
                  if (webOn) imageOn = false;
                });
              }),
              const Divider(height: 1),
              ListTile(
                  leading: const Icon(Icons.photo_camera_outlined),
                  title: const Text('Take photo'),
                  onTap: () {
                    Navigator.pop(context);
                    takePhoto();
                  }),
              ListTile(
                  leading: const Icon(Icons.attach_file),
                  title: const Text('Attach file or image'),
                  onTap: () {
                    Navigator.pop(context);
                    attach();
                  }),
              ListTile(
                  leading: const Icon(Icons.bookmark_border),
                  title: const Text('Prompt library'),
                  onTap: () async {
                    Navigator.pop(context);
                    final p = await Navigator.push<String>(context,
                        MaterialPageRoute(builder: (_) => const PromptsPage()));
                    if (p != null) setState(() => input.text = p);
                  }),
              ListTile(
                  leading: const Icon(Icons.compare_arrows),
                  title: const Text('Compare two models'),
                  onTap: () {
                    Navigator.pop(context);
                    if (models.isEmpty) {
                      snack('Add your API key first.');
                      return;
                    }
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => ComparePage(models)));
                  }),
              _pick('Mode', Icons.tune, mode, modes.keys.toList(),
                  (v) {
                    setState(() {
                      mode = v;
                      chat.mode = v;
                    });
                    savePrefs();
                  }),
              _pick('Thinking effort', Icons.psychology_outlined, effort,
                  efforts, (v) {
                    setState(() => effort = v);
                    savePrefs();
                  }),
              _pick('Voice language', Icons.language, lang,
                  ['bn_BD', 'en_US'], (v) {
                    setState(() => lang = v);
                    Prefs.save();
                    savePrefs();
                  }),
            ])),
          ));

  Widget _opt(IconData i, String title, String sub, bool on, VoidCallback f) =>
      ListTile(
          leading: Icon(i, color: on ? accent : null),
          title: Text(title),
          subtitle: Text(sub, style: const TextStyle(fontSize: 12.5)),
          trailing: on ? const Icon(Icons.check_circle, color: accent) : null,
          onTap: () {
            Navigator.pop(context);
            f();
          });

  Widget _pick(String title, IconData icon, String cur, List<String> items,
          void Function(String) on) =>
      ListTile(
        leading: Icon(icon),
        title: Text(title),
        trailing: DropdownButton<String>(
            value: cur,
            underline: const SizedBox(),
            items: [
              for (final i in items) DropdownMenuItem(value: i, child: Text(i))
            ],
            onChanged: (v) {
              on(v!);
              Navigator.pop(context);
            }),
      );

  void modelSheet() {
    var q = '';
    showModalBottomSheet(
        context: context,
        backgroundColor: bg,
        isScrollControlled: true,
        builder: (_) => StatefulBuilder(builder: (ctx, set) {
              final list = models
                  .where((m) => m.toLowerCase().contains(q.toLowerCase()))
                  .toList();
              return SafeArea(
                  child: Padding(
                      padding: EdgeInsets.only(
                          bottom: MediaQuery.of(ctx).viewInsets.bottom),
                      child: ConstrainedBox(
                          constraints: BoxConstraints(
                              maxHeight: MediaQuery.of(ctx).size.height * 0.75),
                          child: Column(mainAxisSize: MainAxisSize.min, children: [
                            Padding(
                                padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                                child: TextField(
                                    onChanged: (v) => set(() => q = v),
                                    decoration: InputDecoration(
                                        isDense: true,
                                        hintText: 'Search ${models.length} models',
                                        prefixIcon: const Icon(Icons.search),
                                        filled: true,
                                        fillColor: soft,
                                        border: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(14),
                                            borderSide: BorderSide.none)))),
                            Flexible(
                                child: ListView(shrinkWrap: true, children: [
                              if (q.isEmpty)
                                ListTile(
                                    title: const Text('Auto (best model for the task)'),
                                    trailing: model == null
                                        ? const Icon(Icons.check, color: accent)
                                        : null,
                                    onTap: () {
                                      setState(() => model = null);
                                      savePrefs();
                                      Navigator.pop(ctx);
                                    }),
                              for (final m in list)
                                ListTile(
                                    dense: true,
                                    title: Text(m),
                                    trailing: model == m
                                        ? const Icon(Icons.check, color: accent)
                                        : null,
                                    onTap: () {
                                      setState(() => model = m);
                                      savePrefs();
                                      Navigator.pop(ctx);
                                    }),
                            ])),
                          ]))));
            }));
  }

  Future<Pick> smartPick(Task k, String text) async {
    final local = AutoRouter.pick(models, k, _bad);
    final now = DateTime.now().millisecondsSinceEpoch;
    final key = '${k.kind}:${k.cx}:${k.vision}:${k.tools}:${models.length}';
    final hit = _rc[key];
    if (hit != null &&
        now - hit.$2 < 1200000 &&
        !_bad.containsKey(hit.$1.order.first)) {
      return hit.$1;
    }
    final rm = AutoRouter.routerModel(models, _bad);
    if (rm == null) return local;
    try {
      final top = local.order.take(60).toList();
      final lvl = ['simple', 'moderate', 'complex'][k.cx];
      final out = await Api.quick(
          rm,
          AutoRouter.routerPrompt,
          'Models: ${top.join(', ')}\n'
          'Task type: ${k.kind}; complexity: $lvl; image attached: ${k.vision ? 'yes' : 'no'}; tools needed: ${k.tools ? 'yes' : 'no'}; mode: $mode.\n'
          'Task: ${text.length > 500 ? text.substring(0, 500) : text}\n'
          'Local ranking hint (best first): ${top.take(5).join(', ')}');
      Store.addUsage(rm, (AutoRouter.routerPrompt.length + 600) ~/ 4, 40);
      final m = RegExp(r'\{[^{}]*\}').firstMatch(out);
      if (m != null) {
        final j = jsonDecode(m.group(0)!);
        final id = j['model']?.toString();
        if (id != null && top.contains(id)) {
          final e = j['effort']?.toString();
          final eff = ['low', 'medium', 'high'].contains(e) &&
                  AutoRouter.profile(id).reason
              ? e
              : null;
          final p = Pick([id, ...local.order.where((x) => x != id)], eff,
              '${j['reason'] ?? k.kind} (AI-chosen)');
          _rc[key] = (p, now);
          return p;
        }
      }
    } catch (_) {
      _bad[rm] = now;
    }
    return local;
  }

  Future<void> regen() async {
    if (busy || chat.msgs.length < 2) return;
    final u = chat.msgs[chat.msgs.length - 2];
    chat.msgs.removeRange(chat.msgs.length - 2, chat.msgs.length);
    pendImgs = List.of(u.images);
    await send(u.text);
  }

  void editLast() {
    if (busy || chat.msgs.length < 2) return;
    final u = chat.msgs[chat.msgs.length - 2];
    setState(() {
      chat.msgs.removeRange(chat.msgs.length - 2, chat.msgs.length);
      input.text = u.text;
      pendImgs = List.of(u.images);
    });
  }

  List<InlineSpan> inl(String s) {
    final out = <InlineSpan>[];
    final re = RegExp(r'\*\*(.+?)\*\*|`([^`]+)`');
    var i = 0;
    for (final m in re.allMatches(s)) {
      if (m.start > i) out.add(TextSpan(text: s.substring(i, m.start)));
      if (m.group(1) != null) {
        out.add(TextSpan(
            text: m.group(1),
            style: const TextStyle(fontWeight: FontWeight.w700)));
      } else {
        out.add(TextSpan(
            text: m.group(2),
            style: TextStyle(
                fontFamily: 'monospace', backgroundColor: soft)));
      }
      i = m.end;
    }
    if (i < s.length) out.add(TextSpan(text: s.substring(i)));
    return out;
  }

  Widget mdLine(String l, TextStyle base) {
    final h = RegExp(r'^#{1,6}\s+(.*)').firstMatch(l);
    if (h != null) {
      return SelectableText.rich(TextSpan(
          style: base.copyWith(fontSize: 19, fontWeight: FontWeight.w700),
          children: inl(h.group(1)!)));
    }
    final b = RegExp(r'^\s*[-*]\s+(.*)').firstMatch(l);
    if (b != null) {
      return Padding(
          padding: const EdgeInsets.only(left: 12),
          child: SelectableText.rich(TextSpan(
              style: base,
              children: [const TextSpan(text: '•  '), ...inl(b.group(1)!)])));
    }
    return SelectableText.rich(TextSpan(style: base, children: inl(l)));
  }

  Widget md(String t) {
    final bn = RegExp('[\\u0980-\\u09FF]').hasMatch(t);
    final base = TextStyle(
        fontSize: 16.5,
        height: 1.5,
        color: ink,
        fontFamily: (bn || Prefs.font == 'sans') ? null : 'serif');
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      for (final raw in t.split('\n'))
        if (raw.trim().isNotEmpty)
          Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: mdLine(raw.trimRight(), base)),
    ]);
  }

  Widget code(String raw) {
    final nl = raw.indexOf('\n');
    final lang = nl > 0 ? raw.substring(0, nl).trim().toLowerCase() : '';
    final src = nl >= 0 ? raw.substring(nl + 1) : raw;
    return Container(
        margin: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
            color: const Color(0xFF1F1E1B),
            borderRadius: BorderRadius.circular(12)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Padding(
                padding: const EdgeInsets.only(left: 12),
                child: Text(lang.isEmpty ? 'code' : lang,
                    style: const TextStyle(color: Colors.white54, fontSize: 12))),
            const Spacer(),
            if (lang == 'html')
              TextButton(
                  onPressed: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => PreviewPage(src))),
                  child: const Text('Preview')),
            IconButton(
                iconSize: 18,
                color: Colors.white54,
                icon: const Icon(Icons.copy_outlined),
                onPressed: () => Clipboard.setData(ClipboardData(text: src))),
          ]),
          SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
              child: SelectableText(src,
                  style: const TextStyle(
                      fontFamily: 'monospace',
                      fontSize: 13,
                      color: Color(0xFFEDEBE4)))),
        ]));
  }

  Widget body(String t) {
    final parts = t.split('```');
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      for (var i = 0; i < parts.length; i++)
        if (i.isOdd)
          code(parts[i])
        else if (parts[i].trim().isNotEmpty)
          md(parts[i].trim()),
    ]);
  }

  Widget bubble(Msg m) {
    final w = MediaQuery.of(context).size.width * 0.86;
    if (m.user) {
      return Align(
          alignment: Alignment.centerRight,
          child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Container(
              margin: const EdgeInsets.only(top: 14, left: 40),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              constraints: BoxConstraints(maxWidth: w),
              decoration: BoxDecoration(
                  color: soft, borderRadius: BorderRadius.circular(18)),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (m.text.trim().isNotEmpty || m.images.isEmpty)
                      SelectableText(m.text,
                          style: TextStyle(fontSize: 16, height: 1.4, color: ink)),
                    if (m.images.isNotEmpty) imgStrip(m, w: 150),
                  ])),
            if (!busy && chat.msgs.indexOf(m) == chat.msgs.length - 2)
              IconButton(
                  visualDensity: VisualDensity.compact,
                  iconSize: 18,
                  color: mut2,
                  icon: const Icon(Icons.edit_outlined),
                  onPressed: editLast),
          ]));
    }
    return Padding(
        padding: const EdgeInsets.only(top: 14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          m.text.isEmpty ? const Text('…') : body(m.text),
          if (m.images.isNotEmpty) imgStrip(m, w: 300),
          if (m.note.isNotEmpty && Prefs.showNote)
            Padding(
                padding: const EdgeInsets.only(top: 2),
                child: Text(m.note,
                    style: TextStyle(fontSize: 11.5, color: mut2))),
          if (m.text.isNotEmpty)
            Row(mainAxisSize: MainAxisSize.min, children: [
              IconButton(
                  visualDensity: VisualDensity.compact,
                  iconSize: 18,
                  color: mut2,
                  icon: const Icon(Icons.copy_outlined),
                  onPressed: () =>
                      Clipboard.setData(ClipboardData(text: m.text))),
              if (!busy && chat.msgs.last == m)
                IconButton(
                    visualDensity: VisualDensity.compact,
                    iconSize: 18,
                    color: mut2,
                    icon: const Icon(Icons.refresh),
                    onPressed: regen),
            ]),
        ]));
  }

  void newChat({String m = 'Chat', Project? project}) {
    setState(() {
      chat = Chat(DateTime.now().millisecondsSinceEpoch.toString(), 'New chat', [],
          mode: m, pid: project?.id);
      mode = m;
    });
  }

  void openChat(Chat c) {
    setState(() {
      chat = c;
      mode = modes.containsKey(c.mode) ? c.mode : 'Chat';
    });
  }

  void refreshChats() => setState(() {
        if (chat.msgs.isNotEmpty && !Store.chats.contains(chat)) chat = _fresh();
      });

  void handle(Object? r) {
    refreshChats();
    if (r is Project) {
      newChat(project: r);
    } else if (r is Chat) {
      openChat(r);
    }
  }

  String projectName() {
    for (final p in Store.projects) {
      if (p.id == chat.pid) return p.name;
    }
    return 'Project';
  }

  String projectCtx() {
    final ps = Store.projects.where((p) => p.id == chat.pid);
    if (ps.isEmpty) return '';
    final p = ps.first;
    var s = '\n\nThis chat belongs to the project "${p.name}".';
    if (p.instructions.isNotEmpty) {
      s += '\nProject instructions:\n${p.instructions}';
    }
    var left = 60000;
    for (final f in p.files) {
      if (left <= 0) break;
      final t = f['text']!;
      final cut = t.length > left ? t.substring(0, left) : t;
      s += '\n\n[File: ${f['name']}]\n$cut';
      left -= cut.length;
    }
    return s;
  }

  Widget nav(IconData i, String t, VoidCallback f) => ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 22),
      leading: Icon(i, size: 24, color: ink),
      title: Text(t, style: TextStyle(fontSize: 17, color: ink)),
      onTap: f);

  void settingsSheet() => showModalBottomSheet(
      context: context,
      backgroundColor: bg,
      builder: (_) => SafeArea(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
            const SizedBox(height: 8),
            uiRow('API key', icon: Icons.key, onTap: () async {
              Navigator.pop(context);
              await Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const SettingsPage()));
              loadModels();
            }),
            uiRow('User Dashboard', icon: Icons.dashboard_outlined, onTap: () {
              Navigator.pop(context);
              Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const DashboardPage()));
            }),
            uiRow('Connectors (MCP)', icon: Icons.hub_outlined, onTap: () async {
              Navigator.pop(context);
              await Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const ConnectorsPage()));
              _tc.clear();
              _cl.clear();
            }),
            uiRow('Persona & memory',
                icon: Icons.psychology_alt_outlined, onTap: () {
              Navigator.pop(context);
              Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const PersonaPage()));
            }),
            uiRow('Prompt library', icon: Icons.bookmark_border, onTap: () async {
              Navigator.pop(context);
              final p = await Navigator.push<String>(context,
                  MaterialPageRoute(builder: (_) => const PromptsPage()));
              if (p != null) setState(() => input.text = p);
            }),
            uiRow('Compare models', icon: Icons.compare_arrows, onTap: () {
              Navigator.pop(context);
              if (models.isEmpty) {
                snack('Add your API key first.');
                return;
              }
              Navigator.push(context,
                  MaterialPageRoute(builder: (_) => ComparePage(models)));
            }),
            const SizedBox(height: 8),
          ])));

  Widget drawer() => Drawer(
        child: SafeArea(
          child: Column(children: [
            Padding(
                padding: const EdgeInsets.fromLTRB(22, 20, 22, 10),
                child: Row(children: [
                  Image.asset('assets/mark.png', width: 34),
                  const SizedBox(width: 12),
                  Text('Lumora',
                      style: TextStyle(
                          fontSize: 28,
                          fontFamily: 'serif',
                          fontWeight: FontWeight.w600,
                          color: ink)),
                ])),
            nav(Icons.chat_bubble_outline, 'Chats', () async {
              Navigator.pop(context);
              handle(await Navigator.push<Object>(context,
                  MaterialPageRoute(builder: (_) => const ChatsPage())));
            }),
            nav(Icons.folder_open, 'Projects', () async {
              Navigator.pop(context);
              handle(await Navigator.push<Object>(context,
                  MaterialPageRoute(builder: (_) => const ProjectsPage())));
            }),
            nav(Icons.code, 'Code', () {
              Navigator.pop(context);
              newChat(m: 'Code');
            }),
            nav(Icons.work_outline, 'Cowork', () {
              Navigator.pop(context);
              newChat(m: 'Cowork');
            }),
            nav(Icons.auto_awesome_motion_outlined, 'Artifacts', () {
              Navigator.pop(context);
              Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const ArtifactsPage()));
            }),
            Padding(
                padding: EdgeInsets.fromLTRB(22, 8, 22, 4),
                child: Divider(height: 1, color: line)),
            Padding(
                padding: EdgeInsets.fromLTRB(22, 12, 22, 4),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text('Recents',
                        style: TextStyle(
                            fontSize: 14,
                            color: mut,
                            fontWeight: FontWeight.w600)))),
            Expanded(
                child: ListView(children: [
              for (final c in Store.sorted().take(40))
                ListTile(
                    dense: true,
                    contentPadding: const EdgeInsets.only(left: 22, right: 6),
                    selected: c == chat,
                    selectedTileColor: soft,
                    leading: Icon(c.pinned ? Icons.push_pin : modeIcon(c.mode),
                        size: 20),
                    title: Text(c.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 15.5)),
                    trailing: IconButton(
                        icon: const Icon(Icons.more_horiz, size: 20),
                        onPressed: () => chatMenu(context, c, refreshChats)),
                    onLongPress: () => chatMenu(context, c, refreshChats),
                    onTap: () {
                      openChat(c);
                      Navigator.pop(context);
                    }),
            ])),
            Padding(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
                child: Row(children: [
                  InkWell(
                      customBorder: const CircleBorder(),
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => const SettingsHome()))
                            .then((_) {
                          loadModels();
                          refreshChats();
                        });
                      },
                      child: const CircleAvatar(
                          radius: 26,
                          backgroundColor: accent,
                          child: Icon(Icons.tune, color: Colors.white))),
                  const Spacer(),
                  FilledButton.icon(
                      style: FilledButton.styleFrom(
                          backgroundColor: btn,
                          foregroundColor: onBtn,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 22, vertical: 16),
                          shape: const StadiumBorder()),
                      onPressed: () {
                        Navigator.pop(context);
                        newChat();
                      },
                      icon: const Icon(Icons.add),
                      label: const Text('New chat',
                          style: TextStyle(fontSize: 17))),
                ])),
          ]),
        ),
      );

  static const _sugg = {
    'Chat': ['Explain something simply', 'Help me write a message', 'Plan my day'],
    'Code': ['Write a Flutter widget that…', 'Find the bug in this code', 'Explain this error message'],
    'Cowork': ['Plan a project step by step', 'Turn my notes into a summary', 'Draft a work email'],
    'Agent': ['Check my connected apps and summarize', 'Research a topic and report back'],
  };

  Widget empty() {
    final isChat = mode == 'Chat';
    const subs = {
      'Code': 'Write, debug and explain code.',
      'Cowork': 'Plan work and get it done together.',
      'Agent': 'Lumora uses your connectors to finish tasks.',
    };
    final chips = _sugg[mode] ?? _sugg['Chat']!;
    return Center(
        child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              if (isChat)
                Image.asset('assets/logo.png', width: 132)
              else
                Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                        color: accent.withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(22)),
                    child: Icon(modeIcon(mode), size: 40, color: accent)),
              const SizedBox(height: 18),
              Text(live ? 'Listening…' : (isChat ? (Prefs.name.isEmpty ? 'How can I help you today?' : 'Hi ${Prefs.name}, how can I help?') : mode),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 28, fontFamily: 'serif', color: ink)),
              if (subs[mode] != null)
                Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(subs[mode]!,
                        style: TextStyle(color: mut, fontSize: 15))),
              const SizedBox(height: 22),
              Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  alignment: WrapAlignment.center,
                  children: [
                    for (final s in chips)
                      ActionChip(
                          label: Text(s),
                          backgroundColor: surf,
                          side: BorderSide(color: line),
                          onPressed: () => setState(() => input.text = s)),
                  ]),
            ])));
  }

  Future<void> chatAction(String v) async {
    if (v != 'project' && !Store.chats.contains(chat)) {
      snack('Send a message first.');
      return;
    }
    switch (v) {
      case 'pin':
        setState(() => chat.pinned = !chat.pinned);
        await Store.save();
        break;
      case 'copy':
        Clipboard.setData(ClipboardData(
            text: [
          for (final m in chat.msgs) '${m.user ? 'You' : 'Lumora'}: ${m.text}'
        ].join('\n\n')));
        snack('Chat copied to clipboard.');
        break;
      case 'rename':
        await renameChat(context, chat);
        if (mounted) setState(() {});
        break;
      case 'project':
        await pickProject(context, chat);
        if (mounted) setState(() {});
        break;
      case 'delete':
        if (await deleteChat(context, chat)) newChat();
        break;
    }
  }

  PopupMenuItem<String> _mi(String v, IconData i, String t, {bool red = false}) =>
      PopupMenuItem<String>(
          value: v,
          child: Row(children: [
            Icon(i, size: 20, color: red ? Colors.red.shade700 : ink),
            const SizedBox(width: 12),
            Text(t, style: TextStyle(color: red ? Colors.red.shade700 : ink)),
          ]));

  Widget roundBtn(IconData i, VoidCallback f, {bool active = false}) => InkWell(
      customBorder: const CircleBorder(),
      onTap: f,
      child: Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: active ? accent.withValues(alpha: 0.15) : soft),
          child: Icon(i, size: 22, color: active ? accent : ink)));

  Widget filledBtn(IconData i, Color c, VoidCallback f) => InkWell(
      customBorder: const CircleBorder(),
      onTap: f,
      child: Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(shape: BoxShape.circle, color: c),
          child: Icon(i, size: 22, color: c == btn ? onBtn : Colors.white)));

  Widget sendBtn() {
    final blank = input.text.trim().isEmpty && pendImgs.isEmpty && pendText.isEmpty;
    if (busy) return filledBtn(Icons.stop, btn, () => setState(() => cancel = true));
    if (blank) {
      return filledBtn(live ? Icons.close : Icons.graphic_eq,
          live ? accent : btn, toggleLive);
    }
    return filledBtn(Icons.arrow_upward, accent, () => send());
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(chat.msgs.isEmpty ? 'Lumora' : chat.title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
            if (mode != 'Chat' || chat.pid != null)
              Text(
                  [if (mode != 'Chat') mode, if (chat.pid != null) projectName()]
                      .join(' · '),
                  style: TextStyle(fontSize: 11.5, color: mut2)),
          ]),
          actions: [
            IconButton(
                tooltip: 'New chat',
                icon: const Icon(Icons.edit_outlined),
                onPressed: () => newChat(m: mode)),
            PopupMenuButton<String>(
                color: surf,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                onSelected: chatAction,
                itemBuilder: (_) => [
                      _mi('pin', chat.pinned ? Icons.push_pin : Icons.push_pin_outlined,
                          chat.pinned ? 'Unpin' : 'Pin'),
                      _mi('copy', Icons.ios_share, 'Share (copy text)'),
                      _mi('rename', Icons.edit_outlined, 'Rename'),
                      _mi('project', Icons.folder_open, 'Add to project'),
                      _mi('delete', Icons.delete_outline, 'Delete', red: true),
                    ]),
          ],
        ),
        drawer: drawer(),
        body: SafeArea(
          child: Column(children: [
            Expanded(
              child: chat.msgs.isEmpty
                  ? empty()
                  : ListView.builder(
                      controller: scroll,
                      padding: const EdgeInsets.fromLTRB(18, 4, 18, 12),
                      itemCount: chat.msgs.length,
                      itemBuilder: (_, i) => bubble(chat.msgs[i])),
            ),
            if (busy)
              const Padding(
                  padding: EdgeInsets.only(bottom: 6),
                  child: Icon(Icons.auto_awesome, color: accent, size: 20)),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
              child: Container(
                decoration: BoxDecoration(
                    color: surf,
                    borderRadius: BorderRadius.circular(28),
                    border: Border.all(color: line)),
                padding: const EdgeInsets.fromLTRB(16, 8, 10, 10),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  if (pendImgs.isNotEmpty || pendText.isNotEmpty)
                    Padding(
                        padding: const EdgeInsets.only(top: 4, bottom: 4),
                        child: InputChip(
                            label: Text(
                                '${pendImgs.length} image · ${pendText.isEmpty ? 0 : 1} file'),
                            onDeleted: () => setState(() {
                                  pendImgs = [];
                                  pendText = '';
                                }))),
                  if (webOn || deepOn || imageOn)
                    Padding(
                        padding: const EdgeInsets.only(top: 4, bottom: 4),
                        child: Wrap(spacing: 8, children: [
                          if (imageOn)
                            InputChip(
                                avatar: const Icon(Icons.brush_outlined, size: 18),
                                label: ConstrainedBox(
                                    constraints: const BoxConstraints(maxWidth: 190),
                                    child: Text('Create image · $imageLabel',
                                        overflow: TextOverflow.ellipsis)),
                                onPressed: imageOptions,
                                onDeleted: () => setState(() => imageOn = false)),
                          if (deepOn)
                            InputChip(
                                avatar: const Icon(Icons.travel_explore, size: 18),
                                label: const Text('Deep research'),
                                onDeleted: () => setState(() => deepOn = false)),
                          if (webOn)
                            InputChip(
                                avatar: const Icon(Icons.public, size: 18),
                                label: const Text('Web search'),
                                onDeleted: () => setState(() => webOn = false)),
                        ])),
                  TextField(
                      controller: input,
                      minLines: 1,
                      maxLines: 6,
                      onChanged: (_) => setState(() {}),
                      decoration: InputDecoration(
                          hintText: listening
                              ? 'Listening…'
                              : (imageOn
                                  ? 'Describe the image to create'
                                  : (deepOn
                                      ? 'Ask a deep research question'
                                      : 'Message Lumora')),
                          border: InputBorder.none,
                          isDense: true,
                          contentPadding:
                              const EdgeInsets.symmetric(vertical: 10))),
                  if (Prefs.showEstimate && input.text.isNotEmpty)
                    Padding(
                        padding: const EdgeInsets.only(bottom: 4),
                        child: Text(
                            '≈ ${(input.text.length + chat.msgs.fold<int>(0, (a, m) => a + m.text.length)) ~/ 4} input tokens',
                            style: TextStyle(
                                fontSize: 11.5, color: mut2))),
                  const SizedBox(height: 4),
                  Row(children: [
                    roundBtn(Icons.add, toolsSheet),
                    const SizedBox(width: 8),
                    InkWell(
                        borderRadius: BorderRadius.circular(21),
                        onTap: modelSheet,
                        child: Container(
                            height: 42,
                            padding: const EdgeInsets.symmetric(horizontal: 14),
                            decoration: BoxDecoration(
                                color: soft, borderRadius: BorderRadius.circular(21)),
                            child: Row(mainAxisSize: MainAxisSize.min, children: [
                              ConstrainedBox(
                                  constraints: const BoxConstraints(maxWidth: 150),
                                  child: Text(
                                      '${model ?? 'Auto'}${effort != 'auto' ? ' · $effort' : ''}',
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(fontSize: 14.5))),
                              const Icon(Icons.expand_more, size: 18),
                            ]))),
                    const Spacer(),
                    roundBtn(listening ? Icons.stop_circle : Icons.mic_none, mic,
                        active: listening),
                    const SizedBox(width: 8),
                    sendBtn(),
                  ]),
                ]),
              ),
            ),
          ]),
        ),
      );
}
