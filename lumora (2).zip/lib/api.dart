import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'router.dart';

class Api {
  static final http.Client _cl = http.Client();
  static List<String> cached = [];
  static const _ss =
      FlutterSecureStorage(aOptions: AndroidOptions(encryptedSharedPreferences: true));
  static String baseUrl = '', apiKey = '', proto = 'openai', prefix = '/v1';
  static Map<String, String> rate = {};
  static String usagePath = '';
  static int lastIn = 0, lastOut = 0;

  static Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    baseUrl = p.getString('base') ?? '';
    apiKey = '';
    try {
      apiKey = await _ss.read(key: 'apikey') ?? '';
      if (p.containsKey('key')) {
        final old = p.getString('key') ?? '';
        if (apiKey.isEmpty && old.isNotEmpty) {
          await _ss.write(key: 'apikey', value: old);
          apiKey = old;
        }
        await p.remove('key');
      }
    } catch (_) {
      apiKey = p.getString('key') ?? '';
    }
    proto = p.getString('proto') ?? 'openai';
    prefix = p.getString('prefix') ?? '/v1';
    cached = p.getStringList('models_cache') ?? [];
    usagePath = p.getString('usage_path') ?? '';
  }

  static Future<void> save(String b, String k) async {
    final p = await SharedPreferences.getInstance();
    var u = b.trim().replaceAll(RegExp(r'/+$'), '');
    u = u
        .replaceAll(RegExp(r'/(chat/completions|models|messages)$'), '')
        .replaceAll(RegExp(r'/v1$'), '');
    if (u.isNotEmpty && !u.startsWith('http')) u = 'https://$u';
    baseUrl = u;
    apiKey = k.trim();
    await p.setString('base', baseUrl);
    try {
      await _ss.write(key: 'apikey', value: apiKey);
    } catch (_) {
      await p.setString('key', apiKey);
    }
  }

  static bool get ready => baseUrl.isNotEmpty && apiKey.isNotEmpty;
  static String _u(String path) => '$baseUrl$prefix$path';

  static Map<String, String> _hd(String pr) => pr == 'anthropic'
      ? {
          'x-api-key': apiKey,
          'Authorization': 'Bearer $apiKey',
          'anthropic-version': '2023-06-01',
          'Content-Type': 'application/json'
        }
      : {'Authorization': 'Bearer $apiKey', 'Content-Type': 'application/json'};
  static Map<String, String> get _h => _hd(proto);

  static String explain(Object e) {
    if (e is SocketException || e is http.ClientException) {
      return 'Cannot reach the server. Check the Base URL and your internet. ($e)';
    }
    if (e is TimeoutException) return 'The server took too long to respond.';
    if (e is FormatException) {
      return 'Not an API response. Check that the Base URL is correct.';
    }
    return e.toString().replaceFirst('Exception: ', '');
  }

  /// Validates URL + key. Detects OpenAI-style or Anthropic-style servers.
  static Future<List<String>> check(String b, String k) async {
    await save(b, k);
    return models();
  }

  static List<String> _ids(dynamic d) {
    final items = d is List
        ? d
        : (d is Map ? (d['data'] ?? d['models'] ?? d['items'] ?? []) : []);
    final out = <String>[];
    for (final e in (items as List)) {
      final id = e is Map ? (e['id'] ?? e['name'] ?? e['model']) : e;
      if (id != null) out.add(id.toString().replaceFirst('models/', ''));
    }
    return out;
  }

  static void _rl(Map<String, String> h) {
    final re = RegExp(r'ratelimit|rate-limit|remaining|balance|credit|quota',
        caseSensitive: false);
    for (final e in h.entries) {
      if (re.hasMatch(e.key)) rate[e.key] = e.value;
    }
  }

  static Future<(List<String>, String, String)?> _try(
      String pr, String pre, List<String> errs) async {
    try {
      final all = <String>{};
      String? after;
      for (var page = 0; page < 20; page++) {
        final qs = '?limit=1000${after != null ? '&after_id=$after' : ''}';
        var r = await _cl
            .get(Uri.parse('$baseUrl$pre/models$qs'), headers: _hd(pr))
            .timeout(const Duration(seconds: 12));
        if (r.statusCode != 200 && page == 0) {
          r = await _cl
              .get(Uri.parse('$baseUrl$pre/models'), headers: _hd(pr))
              .timeout(const Duration(seconds: 12));
        }
        if (r.statusCode != 200) {
          if (page == 0) {
            errs.add(
                '$pr$pre: HTTP ${r.statusCode}${r.statusCode == 401 || r.statusCode == 403 ? ' (key rejected)' : ''}');
          }
          break;
        }
        _rl(r.headers);
        final d = jsonDecode(utf8.decode(r.bodyBytes));
        all.addAll(_ids(d));
        if (d is Map && d['has_more'] == true && d['last_id'] != null) {
          after = d['last_id'].toString();
        } else {
          break;
        }
      }
      if (all.isNotEmpty) return (all.toList()..sort(), pr, pre);
    } catch (e) {
      errs.add('$pr$pre: ${explain(e)}');
    }
    return null;
  }

  /// Lists every model. Tries the last working style first, then the rest in parallel.
  static Future<List<String>> models() async {
    final errs = <String>[];
    final combos = <(String, String)>[(proto, prefix)];
    for (final pr in ['openai', 'anthropic']) {
      for (final pre in ['/v1', '']) {
        if (!(pr == proto && pre == prefix)) combos.add((pr, pre));
      }
    }
    var hit = await _try(combos.first.$1, combos.first.$2, errs);
    if (hit == null) {
      final done = Completer<(List<String>, String, String)?>();
      var left = combos.length - 1;
      for (final c in combos.skip(1)) {
        _try(c.$1, c.$2, errs).then((r) {
          left--;
          if (r != null && !done.isCompleted) {
            done.complete(r);
          } else if (left == 0 && !done.isCompleted) {
            done.complete(null);
          }
        });
      }
      hit = await done.future;
    }
    if (hit == null) {
      if (errs.isEmpty) errs.add('The server returned an empty model list.');
      throw Exception(errs.toSet().join(' | '));
    }
    proto = hit.$2;
    prefix = hit.$3;
    cached = hit.$1;
    final p = await SharedPreferences.getInstance();
    await p.setString('proto', proto);
    await p.setString('prefix', prefix);
    await p.setStringList('models_cache', cached);
    return hit.$1;
  }

  static String _n(dynamic v) => v is num
      ? (v % 1 == 0 ? v.toInt().toString() : v.toStringAsFixed(2))
      : v.toString();

  static List<List<String>> _rows(dynamic d) {
    final r = <List<String>>[];
    if (d is! Map) return r;
    final x = d['data'] is Map ? d['data'] as Map : d;
    void add(String label, List<String> keys) {
      for (final k in keys) {
        if (x[k] != null) {
          r.add([label, _n(x[k])]);
          return;
        }
      }
    }

    add('Key name', ['name']);
    add('Total granted', ['total_granted', 'hard_limit_usd', 'total']);
    add('Used', ['total_used', 'used']);
    add('Remaining', ['total_available', 'remaining', 'balance', 'available']);
    add('Account limit (USD)', ['system_hard_limit_usd']);
    if (x['unlimited_quota'] == true) r.add(['Quota', 'Unlimited']);
    final exp = x['expires_at'] ?? x['access_until'] ?? x['expire_time'];
    if (exp is num && exp > 0) {
      final ms = (exp > 1e12 ? exp : exp * 1000).toInt();
      r.add(['Expires', DateTime.fromMillisecondsSinceEpoch(ms).toString().substring(0, 10)]);
    }
    return r;
  }

  static Future<void> setUsagePath(String v) async {
    usagePath = v.trim();
    final p = await SharedPreferences.getInstance();
    await p.setString('usage_path', usagePath);
  }

  static String _full(String p) =>
      p.startsWith('http') ? p : '$baseUrl${p.startsWith('/') ? '' : '/'}$p';

  static String _pretty(String k) => k
      .replaceAll(RegExp(r'[_\-]+'), ' ')
      .split(' ')
      .where((w) => w.isNotEmpty)
      .map((w) => w[0].toUpperCase() + w.substring(1))
      .join(' ');

  static String _val(String key, dynamic v) {
    if (v is bool) return v ? 'Yes' : 'No';
    if (v is num) {
      if (RegExp(r'time|expire|reset|until|_at$', caseSensitive: false).hasMatch(key) &&
          v > 1e9) {
        final ms = (v > 1e12 ? v : v * 1000).toInt();
        return DateTime.fromMillisecondsSinceEpoch(ms).toString().substring(0, 16);
      }
      if (v is int || v % 1 == 0) {
        final s = v.toInt().toString();
        return s.replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ',');
      }
      return v.toStringAsFixed(2);
    }
    return v.toString();
  }

  /// Turns any JSON into readable label/value rows.
  static void _flat(dynamic j, String path, int depth, List<List<String>> out) {
    if (out.length >= 40) return;
    if (j is Map) {
      j.forEach((k, v) {
        final key = k.toString();
        final label = path.isEmpty ? _pretty(key) : '$path › ${_pretty(key)}';
        if (v is Map && depth < 3) {
          _flat(v, label, depth + 1, out);
        } else if (v is List) {
          if (v.isNotEmpty && v.every((e) => e is! Map && e is! List) && v.length <= 6) {
            out.add([label, v.join(', ')]);
          } else if (v.isNotEmpty && v.first is Map && depth < 2) {
            for (var i = 0; i < v.length && i < 3; i++) {
              _flat(v[i], '$label ${i + 1}', depth + 1, out);
            }
          } else {
            out.add([label, '${v.length} items']);
          }
        } else if (v != null && v is! Map) {
          out.add([label, _val(key, v)]);
        }
      });
    }
  }

  /// Finds key limits/balance: your own usage address first, then common ones, all in parallel.
  static Future<Map<String, dynamic>> quotaInfo() async {
    final custom = usagePath.trim();
    final paths = <String>[
      if (custom.isNotEmpty) custom,
      '/api/usage/token',
      '/v1/dashboard/billing/subscription',
      '/dashboard/billing/subscription',
      '/v1/usage',
      '/usage',
      '/v1/credits',
      '/v1/me',
      '/v1/user',
      '/v1/account',
      '/v1/key',
      '/v1/key/info',
      '/v1/balance',
      '/api/user/self',
      '/api/token/usage',
      '/api/usage'
    ];
    final n = DateTime.now();
    String ds(DateTime d) => d.toIso8601String().substring(0, 10);
    final usageF = (() async {
      try {
        final r = await http
            .get(
                Uri.parse(
                    '$baseUrl/v1/dashboard/billing/usage?start_date=${ds(DateTime(n.year, n.month, 1))}&end_date=${ds(n.add(const Duration(days: 1)))}'),
                headers: _h)
            .timeout(const Duration(seconds: 6));
        if (r.statusCode == 200) {
          final j = jsonDecode(utf8.decode(r.bodyBytes));
          if (j is Map && j['total_usage'] is num) {
            return ['Used this month (USD)', ((j['total_usage'] as num) / 100).toStringAsFixed(2)];
          }
        }
      } catch (_) {}
      return null;
    })();
    final res = await Future.wait(paths.map((p) async {
      try {
        final r = await http
            .get(Uri.parse(_full(p)), headers: _h)
            .timeout(const Duration(seconds: 8));
        _rl(r.headers);
        final b = r.body.trim();
        if (r.statusCode != 200 || !(b.startsWith('{') || b.startsWith('['))) return null;
        return jsonDecode(utf8.decode(r.bodyBytes));
      } catch (_) {
        return null;
      }
    }));
    final rows = <List<String>>[];
    String? raw, src;
    for (var i = 0; i < paths.length; i++) {
      final j = res[i];
      if (j == null) continue;
      raw ??= const JsonEncoder.withIndent('  ').convert(j);
      var rr = _rows(j);
      if (rr.isEmpty && custom.isNotEmpty && i == 0) {
        rr = [];
        _flat(j, '', 0, rr);
      }
      if (rr.isNotEmpty) {
        rows.addAll(rr);
        src = paths[i];
        raw = const JsonEncoder.withIndent('  ').convert(j);
        break;
      }
    }
    final u = await usageF;
    if (u != null) rows.add(List<String>.from(u));
    return {'rows': rows, 'raw': raw, 'src': src};
  }

  // Converts OpenAI-style messages to Anthropic format.
  static (String, List<Map<String, dynamic>>) _anth(
      List<Map<String, dynamic>> msgs) {
    var sys = '';
    final out = <Map<String, dynamic>>[];
    for (final m in msgs) {
      final role = m['role'];
      final c = m['content'];
      if (role == 'system') {
        sys += '$c\n';
        continue;
      }
      if (role == 'tool') {
        out.add({
          'role': 'user',
          'content': [
            {
              'type': 'tool_result',
              'tool_use_id': m['tool_call_id'],
              'content': c.toString()
            }
          ]
        });
        continue;
      }
      final blocks = <Map<String, dynamic>>[];
      if (c is String) {
        if (c.isNotEmpty) blocks.add({'type': 'text', 'text': c});
      } else if (c is List) {
        for (final p in c) {
          if (p['type'] == 'text') {
            blocks.add({'type': 'text', 'text': p['text']});
          } else {
            final u = p['image_url']['url'] as String;
            blocks.add({
              'type': 'image',
              'source': {
                'type': 'base64',
                'media_type': u.substring(5, u.indexOf(';')),
                'data': u.substring(u.indexOf(',') + 1)
              }
            });
          }
        }
      }
      for (final tc in (m['tool_calls'] as List? ?? [])) {
        blocks.add({
          'type': 'tool_use',
          'id': tc['id'],
          'name': tc['function']['name'],
          'input': jsonDecode(tc['function']['arguments'] ?? '{}')
        });
      }
      if (blocks.isEmpty) blocks.add({'type': 'text', 'text': '…'});
      out.add({'role': role, 'content': blocks});
    }
    return (sys.trim(), out);
  }


  // ------------------------------------------------------------ Images
  static bool isImageModel(String m) => RegExp(
          r'image|dall-?e|imagen|flux|sdxl|stable-diffusion|midjourney|seedream|nano-banana|cogview|kolors',
          caseSensitive: false)
      .hasMatch(m);

  static final _dataRe =
      RegExp(r'data:image/[a-zA-Z+.\-]+;base64,[A-Za-z0-9+/=\r\n]+');
  static final _mdUrlRe = RegExp(r'!\[[^\]]*\]\((https?://[^)\s]+)\)');

  static Future<String> _toDataUrl(String url) async {
    if (url.startsWith('data:')) return url.replaceAll(RegExp(r'\s'), '');
    final r = await _cl.get(Uri.parse(url)).timeout(const Duration(seconds: 60));
    if (r.statusCode != 200) {
      throw Exception('Could not download the image (HTTP ${r.statusCode}).');
    }
    final ct = (r.headers['content-type'] ?? 'image/png').split(';').first;
    return 'data:${ct.startsWith('image/') ? ct : 'image/png'};base64,${base64Encode(r.bodyBytes)}';
  }

  static String _short(String s) {
    final t = s.replaceAll(RegExp(r'\s+'), ' ').trim();
    return t.length > 220 ? '${t.substring(0, 220)}…' : t;
  }

  static Future<List<String>> _fromChatMessage(Map msg) async {
    final out = <String>[];
    for (final i in ((msg['images'] as List?) ?? [])) {
      final u = ((i is Map && i['image_url'] is Map ? i['image_url']['url'] : null) ??
              (i is Map ? i['url'] : null) ??
              '')
          .toString();
      if (u.isNotEmpty) out.add(await _toDataUrl(u));
    }
    final raw = msg['content'];
    final c = raw is String ? raw : jsonEncode(raw ?? '');
    for (final m in _dataRe.allMatches(c)) {
      out.add(m.group(0)!.replaceAll(RegExp(r'\s'), ''));
    }
    for (final m in _mdUrlRe.allMatches(c)) {
      out.add(await _toDataUrl(m.group(1)!));
    }
    return out;
  }

  /// Free image service (no key). Small images (max 768 px), may carry a logo,
  /// and the free tier allows about one image every 45 seconds.
  static Future<String> freeImage(String prompt, String size) async {
    var w = 768, h = 768;
    if (size == '1024x1536') {
      w = 576;
      h = 864;
    } else if (size == '1536x1024') {
      w = 864;
      h = 576;
    }
    final p = prompt.length > 600 ? prompt.substring(0, 600) : prompt;
    final seed = DateTime.now().millisecondsSinceEpoch % 100000;
    final r = await _cl
        .get(Uri.parse(
            'https://image.pollinations.ai/prompt/${Uri.encodeComponent(p)}?width=$w&height=$h&seed=$seed'))
        .timeout(const Duration(seconds: 120));
    if (r.statusCode == 402 || r.statusCode == 429) {
      throw Exception(
          'The free image service is busy (about one image per 45 seconds). Wait a little and try again.');
    }
    if (r.statusCode != 200) {
      throw Exception('Free image service: HTTP ${r.statusCode}');
    }
    final ct = (r.headers['content-type'] ?? '').split(';').first;
    if (!ct.startsWith('image/')) {
      throw Exception('Free image service did not return an image.');
    }
    return 'data:$ct;base64,${base64Encode(r.bodyBytes)}';
  }

  /// Creates an image. Tries, in order: the standard images API, the same
  /// without a size, a chat call that asks for image output, a plain chat
  /// call, and the Gemini-native endpoint. Returns data-URLs.
  /// On failure the error lists what each attempt said.
  static Future<List<String>> generateImage(String model, String prompt,
      {String size = '1024x1024'}) async {
    final h = _hd('openai');
    final pre = prefix;
    const wait = Duration(seconds: 300);

    Future<List<String>> imagesApi(bool withSize) async {
      final r = await _cl
          .post(Uri.parse('$baseUrl$pre/images/generations'),
              headers: h,
              body: jsonEncode({
                'model': model,
                'prompt': prompt,
                'n': 1,
                if (withSize && size != 'default') 'size': size,
              }))
          .timeout(wait);
      if (r.statusCode != 200) {
        throw Exception('HTTP ${r.statusCode} ${_short(r.body)}');
      }
      _rl(r.headers);
      final d = jsonDecode(utf8.decode(r.bodyBytes));
      final out = <String>[];
      for (final e in ((d['data'] as List?) ?? [])) {
        if (e['b64_json'] != null) {
          out.add('data:image/png;base64,${e['b64_json']}');
        } else if (e['url'] != null) {
          out.add(await _toDataUrl(e['url'].toString()));
        }
      }
      if (out.isEmpty) throw Exception('empty reply ${_short(r.body)}');
      return out;
    }

    Future<List<String>> chatApi(bool modal) async {
      final r = await _cl
          .post(Uri.parse('$baseUrl$pre/chat/completions'),
              headers: h,
              body: jsonEncode({
                'model': model,
                'messages': [
                  {'role': 'user', 'content': prompt}
                ],
                if (modal) 'modalities': ['image', 'text'],
              }))
          .timeout(wait);
      if (r.statusCode != 200) {
        throw Exception('HTTP ${r.statusCode} ${_short(r.body)}');
      }
      final d = jsonDecode(utf8.decode(r.bodyBytes));
      final msg = Map<String, dynamic>.from(d['choices'][0]['message']);
      final out = await _fromChatMessage(msg);
      if (out.isEmpty) {
        throw Exception('no image in the reply: ${_short('${msg['content'] ?? r.body}')}');
      }
      return out;
    }

    Future<List<String>> geminiApi() async {
      final r = await _cl
          .post(Uri.parse('$baseUrl/v1beta/models/$model:generateContent'),
              headers: {...h, 'x-goog-api-key': apiKey},
              body: jsonEncode({
                'contents': [
                  {
                    'role': 'user',
                    'parts': [
                      {'text': prompt}
                    ]
                  }
                ],
                'generationConfig': {
                  'responseModalities': ['TEXT', 'IMAGE']
                },
              }))
          .timeout(wait);
      if (r.statusCode != 200) {
        throw Exception('HTTP ${r.statusCode} ${_short(r.body)}');
      }
      final d = jsonDecode(utf8.decode(r.bodyBytes));
      final out = <String>[];
      for (final c in ((d['candidates'] as List?) ?? [])) {
        for (final p in ((c['content']?['parts'] as List?) ?? [])) {
          final inl = p['inlineData'] ?? p['inline_data'];
          if (inl != null && inl['data'] != null) {
            out.add(
                'data:${inl['mimeType'] ?? inl['mime_type'] ?? 'image/png'};base64,${inl['data']}');
          }
        }
      }
      if (out.isEmpty) throw Exception('no image in the reply ${_short(r.body)}');
      return out;
    }

    final steps = <(String, Future<List<String>> Function())>[
      ('images API', () => imagesApi(true)),
      if (size != 'default') ('images API without size', () => imagesApi(false)),
      ('chat with image output', () => chatApi(true)),
      ('plain chat', () => chatApi(false)),
      ('Gemini endpoint', geminiApi),
    ];
    final errs = <String>[];
    for (final (label, f) in steps) {
      try {
        final o = await f();
        if (o.isNotEmpty) return o.toSet().toList();
      } catch (e) {
        final m = e.toString().replaceFirst('Exception: ', '');
        errs.add('• $label: $m');
        // key problems, no balance, or rate limits will not change on retry
        if (RegExp(r'^HTTP (401|402|403|429)').hasMatch(m)) break;
      }
    }
    throw Exception(errs.join('\n'));
  }

  /// Non-streaming completion with a custom token limit and timeout.
  static Future<String> complete(String model, String system, String user,
      {int maxTokens = 600, int secs = 40}) async {
    final anth = proto == 'anthropic';
    final body = anth
        ? {
            'model': model,
            'max_tokens': maxTokens,
            'system': system,
            'messages': [
              {'role': 'user', 'content': user}
            ]
          }
        : {
            'model': model,
            'max_tokens': maxTokens,
            'messages': [
              {'role': 'system', 'content': system},
              {'role': 'user', 'content': user}
            ]
          };
    final r = await _cl
        .post(Uri.parse(_u(anth ? '/messages' : '/chat/completions')),
            headers: _h, body: jsonEncode(body))
        .timeout(Duration(seconds: secs));
    if (r.statusCode != 200) throw Exception('HTTP ${r.statusCode}: ${r.body}');
    final d = jsonDecode(utf8.decode(r.bodyBytes));
    if (anth) {
      return (d['content'] as List)
          .where((b) => b['type'] == 'text')
          .map((b) => b['text'])
          .join();
    }
    return (d['choices'][0]['message']['content'] ?? '').toString();
  }

  static Future<Map<String, dynamic>> chatOnce(
      String model,
      List<Map<String, dynamic>> msgs,
      String? effort,
      List<Map<String, dynamic>> tools) async {
    final anth = proto == 'anthropic';
    Map<String, dynamic> body;
    if (anth) {
      final (sys, am) = _anth(msgs);
      body = {
        'model': model,
        'max_tokens': 4096,
        if (sys.isNotEmpty) 'system': sys,
        'messages': am,
        'tools': [
          for (final t in tools)
            {
              'name': t['function']['name'],
              'description': t['function']['description'],
              'input_schema': t['function']['parameters']
            }
        ],
      };
    } else {
      body = {
        'model': model,
        'messages': msgs,
        'tools': tools,
        if (effort != null) 'reasoning_effort': effort,
      };
    }
    final r = await _cl
        .post(Uri.parse(_u(anth ? '/messages' : '/chat/completions')),
            headers: _h, body: jsonEncode(body))
        .timeout(const Duration(seconds: 180));
    if (r.statusCode != 200) throw Exception('HTTP ${r.statusCode}: ${r.body}');
    _rl(r.headers);
    final d = jsonDecode(utf8.decode(r.bodyBytes));
    final u = d['usage'];
    if (u != null) {
      lastIn += (u[anth ? 'input_tokens' : 'prompt_tokens'] ?? 0) as int;
      lastOut += (u[anth ? 'output_tokens' : 'completion_tokens'] ?? 0) as int;
    }
    if (!anth) return Map<String, dynamic>.from(d['choices'][0]['message']);
    final blocks = (d['content'] as List?) ?? [];
    return {
      'content':
          blocks.where((b) => b['type'] == 'text').map((b) => b['text']).join(),
      'tool_calls': [
        for (final b in blocks.where((b) => b['type'] == 'tool_use'))
          {
            'id': b['id'],
            'type': 'function',
            'function': {'name': b['name'], 'arguments': jsonEncode(b['input'])}
          }
      ],
    };
  }

  static Stream<String> chat(
      String model, List<Map<String, dynamic>> msgs, String? effort) async* {
    lastIn = lastOut = 0;
    final anth = proto == 'anthropic';
    final req = http.Request(
        'POST', Uri.parse(_u(anth ? '/messages' : '/chat/completions')));
    req.headers.addAll(_h);
    if (anth) {
      final (sys, am) = _anth(msgs);
      req.body = jsonEncode({
        'model': model,
        'max_tokens': 4096,
        if (sys.isNotEmpty) 'system': sys,
        'messages': am,
        'stream': true,
      });
    } else {
      req.body = jsonEncode({
        'model': model,
        'messages': msgs,
        'stream': true,
        'stream_options': {'include_usage': true},
        if (effort != null) 'reasoning_effort': effort,
      });
    }
    try {
      final res = await _cl.send(req);
      _rl(res.headers);
      if (res.statusCode != 200) {
        throw Exception(
            'HTTP ${res.statusCode}: ${await res.stream.bytesToString()}');
      }
      await for (final line in res.stream
          .transform(utf8.decoder)
          .transform(const LineSplitter())) {
        if (!line.startsWith('data:')) continue;
        final s = line.substring(5).trim();
        if (s == '[DONE]') break;
        try {
          final d = jsonDecode(s);
          if (anth) {
            final t = d['type'];
            if (t == 'content_block_delta' &&
                d['delta']['type'] == 'text_delta') {
              yield d['delta']['text'].toString();
            }
            if (t == 'message_start') {
              lastIn = (d['message']['usage']['input_tokens'] ?? 0) as int;
            }
            if (t == 'message_delta') {
              lastOut = (d['usage']['output_tokens'] ?? 0) as int;
            }
          } else {
            final u = d['usage'];
            if (u != null) {
              lastIn = (u['prompt_tokens'] ?? 0) as int;
              lastOut = (u['completion_tokens'] ?? 0) as int;
            }
            final ch = d['choices'] as List?;
            if (ch != null && ch.isNotEmpty) {
              final t = ch[0]['delta']['content'];
              if (t != null) yield t.toString();
            }
          }
        } catch (_) {}
      }
    } finally {}
  }
}
