import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'api.dart';
import 'store.dart';

class Hit {
  final String title, url, snippet;
  String text = '';
  Hit(this.title, this.url, this.snippet);
}

/// Web search + page reading + Deep Research. No backend needed.
/// Search order: Tavily (if you set a key) -> DuckDuckGo (free) -> Wikipedia.
class Web {
  static const _ua =
      'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36';

  static String _dec(String s) => s
      .replaceAll('&amp;', '&')
      .replaceAll('&quot;', '"')
      .replaceAll('&#x27;', "'")
      .replaceAll('&#39;', "'")
      .replaceAll('&lt;', '<')
      .replaceAll('&gt;', '>')
      .replaceAll('&nbsp;', ' ');

  static String _strip(String s) =>
      _dec(s.replaceAll(RegExp(r'<[^>]*>'), '')).replaceAll(RegExp(r'\s+'), ' ').trim();

  static String _real(String h) {
    var u = _dec(h);
    final m = RegExp(r'[?&]uddg=([^&]+)').firstMatch(u);
    if (m != null) u = Uri.decodeComponent(m.group(1)!);
    if (u.startsWith('//')) u = 'https:$u';
    return u;
  }

  static String _key(String url) {
    try {
      final u = Uri.parse(url);
      return '${u.host}${u.path}'.toLowerCase().replaceAll(RegExp(r'/+$'), '');
    } catch (_) {
      return url;
    }
  }

  // ----------------------------------------------------------------- search
  static Future<List<Hit>> _tavily(String q, int n) async {
    final r = await http
        .post(Uri.parse('https://api.tavily.com/search'),
            headers: {
              'Content-Type': 'application/json',
              'Authorization': 'Bearer ${Prefs.searchKey}'
            },
            body: jsonEncode({
              'api_key': Prefs.searchKey,
              'query': q,
              'max_results': n,
            }))
        .timeout(const Duration(seconds: 20));
    if (r.statusCode != 200) throw Exception('Tavily HTTP ${r.statusCode}');
    final d = jsonDecode(utf8.decode(r.bodyBytes));
    return [
      for (final e in ((d['results'] as List?) ?? []))
        Hit(_strip('${e['title'] ?? ''}'), '${e['url'] ?? ''}',
            _strip('${e['content'] ?? ''}')),
    ].where((h) => h.url.startsWith('http')).toList();
  }

  static Future<List<Hit>> _ddg(String q, int n) async {
    final r = await http.get(
        Uri.parse('https://html.duckduckgo.com/html/?q=${Uri.encodeQueryComponent(q)}'),
        headers: {'User-Agent': _ua, 'Accept-Language': 'en-US,en;q=0.8,bn;q=0.6'}).timeout(
        const Duration(seconds: 15));
    if (r.statusCode != 200) throw Exception('DuckDuckGo HTTP ${r.statusCode}');
    final body = utf8.decode(r.bodyBytes, allowMalformed: true);
    final links = RegExp(
            r'<a[^>]*class="result__a"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)</a>')
        .allMatches(body)
        .toList();
    final snips = RegExp(r'class="result__snippet"[^>]*>([\s\S]*?)</a>')
        .allMatches(body)
        .toList();
    final out = <Hit>[];
    for (var i = 0; i < links.length && out.length < n; i++) {
      final u = _real(links[i].group(1)!);
      if (!u.startsWith('http') || u.contains('duckduckgo.com/y.js')) continue;
      out.add(Hit(_strip(links[i].group(2)!), u,
          i < snips.length ? _strip(snips[i].group(1)!) : ''));
    }
    return out;
  }

  static Future<List<Hit>> _wiki(String q, int n) async {
    final bn = RegExp('[\\u0980-\\u09FF]').hasMatch(q);
    final host = bn ? 'bn.wikipedia.org' : 'en.wikipedia.org';
    final r = await http
        .get(Uri.parse(
            'https://$host/w/api.php?action=query&list=search&srsearch=${Uri.encodeQueryComponent(q)}&format=json&utf8=1&srlimit=$n'))
        .timeout(const Duration(seconds: 12));
    if (r.statusCode != 200) return [];
    final d = jsonDecode(utf8.decode(r.bodyBytes));
    return [
      for (final e in ((d['query']?['search'] as List?) ?? []))
        Hit(
            '${e['title']}',
            'https://$host/wiki/${Uri.encodeComponent('${e['title']}'.replaceAll(' ', '_'))}',
            _strip('${e['snippet'] ?? ''}')),
    ];
  }

  static Future<List<Hit>> search(String q, {int n = 6}) async {
    if (Prefs.searchKey.trim().isNotEmpty) {
      try {
        final h = await _tavily(q, n);
        if (h.isNotEmpty) return h;
      } catch (_) {}
    }
    try {
      final h = await _ddg(q, n);
      if (h.isNotEmpty) return h;
    } catch (_) {}
    try {
      return await _wiki(q, n);
    } catch (_) {}
    return [];
  }

  // ------------------------------------------------------------ read a page
  static Future<void> _load(Hit h, int max) async {
    try {
      final r = await http.get(Uri.parse(h.url), headers: {
        'User-Agent': _ua,
        'Accept': 'text/html,text/plain;q=0.9,*/*;q=0.5'
      }).timeout(const Duration(seconds: 12));
      final ct = (r.headers['content-type'] ?? '').toLowerCase();
      if (r.statusCode != 200 || !(ct.contains('html') || ct.contains('text/plain'))) {
        return;
      }
      var s = utf8.decode(r.bodyBytes, allowMalformed: true);
      s = s.replaceAll(
          RegExp(r'<(script|style|noscript|svg|nav|header|footer|form|aside)[\s\S]*?</\1>',
              caseSensitive: false),
          ' ');
      s = s.replaceAll(RegExp(r'<!--[\s\S]*?-->'), ' ');
      s = _strip(s);
      if (s.length > max) s = s.substring(0, max);
      h.text = s;
    } catch (_) {}
  }

  static String context(List<Hit> hits) {
    final b = StringBuffer();
    for (var i = 0; i < hits.length; i++) {
      final h = hits[i];
      b.writeln(
          '[${i + 1}] ${h.title}\nURL: ${h.url}\n${h.text.isNotEmpty ? h.text : h.snippet}\n');
    }
    return b.toString();
  }

  static String sourcesList(List<Hit> hits) => [
        for (var i = 0; i < hits.length; i++) '${i + 1}. ${hits[i].title}\n   ${hits[i].url}'
      ].join('\n');

  static String _today() => DateTime.now().toIso8601String().substring(0, 10);

  static String webIntro() =>
      'Today is ${_today()}. Live web search results are below. Use them to answer the request, '
      'cite sources inline as [1], [2] matching the numbers, and say so if the results are weak or conflicting. '
      'Do not invent facts or links. Reply in the user\'s language.';

  static String deepIntro() =>
      'Today is ${_today()}. You are doing DEEP RESEARCH. Many web sources are below. '
      'Write a thorough, well-organized report in the user\'s language: a short summary first, '
      'then sections with headings, concrete facts, numbers and dates, differences between sources, '
      'open questions, and a conclusion. Cite sources inline as [1], [2] matching the numbers. '
      'Use only the sources; clearly say what is missing or uncertain. Do not add a sources list (it is added automatically).';

  // ---------------------------------------------------------- quick search
  /// Rewrites a follow-up into a standalone search query (falls back to the text).
  static Future<String> query(String model, List<String> recent, String q) async {
    final plain = q.length > 200 ? q.substring(0, 200) : q;
    if (recent.isEmpty) return plain;
    try {
      final r = await Api.complete(
          model,
          'Turn the user\'s last message into ONE standalone web search query, using the earlier conversation for context. Output only the query, no quotes.',
          'Conversation:\n${recent.join('\n')}\n\nLast message: $q',
          maxTokens: 60,
          secs: 12);
      final s = r.trim().replaceAll('"', '');
      return s.isEmpty ? plain : s;
    } catch (_) {
      return plain;
    }
  }

  static Future<List<Hit>> quick(String q, void Function(String) say) async {
    say('🔎 Searching the web…');
    final hits = await search(q, n: 6);
    if (hits.isEmpty) {
      throw Exception('No web results. Check your internet connection.');
    }
    final top = hits.take(3).toList();
    say('📖 Reading ${top.length} pages…');
    await Future.wait(top.map((h) => _load(h, 3500)));
    return hits;
  }

  // --------------------------------------------------------- deep research
  static Future<List<Hit>> deep(
      String question, String model, void Function(String) say) async {
    say('🧭 Planning the research…');
    var qs = <String>[];
    try {
      final raw = await Api.complete(
          model,
          'You are a research planner. Output ONLY a JSON array of 4 to 6 short, distinct web search queries that together cover the question from different angles (definitions, latest news, numbers, expert views, comparisons). Use the language most likely to find good sources.',
          'Today: ${_today()}\nQuestion: $question',
          maxTokens: 400,
          secs: 40);
      final a = raw.indexOf('['), b = raw.lastIndexOf(']');
      if (a >= 0 && b > a) {
        qs = (jsonDecode(raw.substring(a, b + 1)) as List)
            .map((e) => e.toString().trim())
            .where((e) => e.isNotEmpty)
            .take(6)
            .toList();
      }
    } catch (_) {}
    if (qs.isEmpty) {
      qs = [question.length > 200 ? question.substring(0, 200) : question];
    }
    say('🔎 Searching ${qs.length} angles…');
    final res = await Future.wait(
        qs.map((q) => search(q, n: 6).catchError((_) => <Hit>[])));
    final seen = <String>{};
    final hits = <Hit>[];
    for (var i = 0; i < 6; i++) {
      for (final r in res) {
        if (i < r.length && seen.add(_key(r[i].url))) hits.add(r[i]);
      }
    }
    final top = hits.take(10).toList();
    if (top.isEmpty) {
      throw Exception('No web results. Check your internet connection.');
    }
    say('📖 Reading ${top.length} sources…');
    await Future.wait(top.map((h) => _load(h, 3500)));
    say('✍️ Writing the report…');
    return top;
  }
}
