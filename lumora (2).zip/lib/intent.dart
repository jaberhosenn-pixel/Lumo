/// Detects from the user's own message whether they want an image,
/// a web search or deep research, so no menu selection is needed.
enum Intent { chat, image, web, deep }

class Intents {
  static final _howTo = RegExp(
      r'\b(how|why|what is|what are|difference|explain|tutorial|meaning)\b|কিভাবে|কীভাবে|কেন|ব্যাখ্যা|মানে কী|মানে কি',
      caseSensitive: false);

  static final _imgEn = RegExp(
      r'^\s*(please\s+|pls\s+|can you\s+|could you\s+|will you\s+|i want you to\s+)?(create|generate|make|draw|design|paint|render|produce|imagine)\b.{0,60}\b(image|picture|photo|illustration|logo|poster|wallpaper|artwork|icon|banner|portrait|drawing|painting|sketch|avatar|thumbnail)s?\b',
      caseSensitive: false);
  static final _imgEn2 = RegExp(
      r'^\s*(show me|give me|i want|i need|i would like)\b.{0,30}\b(image|picture|photo|pic|illustration|logo|poster)s?\b',
      caseSensitive: false);
  static final _imgBn = RegExp(
      r'(ছবি|ইমেজ|ফটো|লোগো|পোস্টার|ওয়ালপেপার|চিত্র|কার্টুন|থাম্বনেইল)[^\n।?]{0,60}(বানাও|বানিয়ে|বানাতে|তৈরি|তৈরী|আঁক|এঁকে|ক্রিয়েট|জেনারেট|করে দাও)|(ক্রিয়েট|জেনারেট|বানাও|বানিয়ে দাও|তৈরি করো|আঁকো)[^\n।?]{0,40}(ছবি|ইমেজ|ফটো|লোগো|পোস্টার)');
  static final _imgBl = RegExp(
      r'\b(chobi|chhobi|image|photo|logo|poster)\b.{0,40}\b(banao|banaw|banai|kor|koro|create|generate|anko|aka)\b',
      caseSensitive: false);

  static final _deep = RegExp(
      r'deep(ly)?[\s-]*(research|dive|dig)|\bdeep(ly)?\b[^\n]{0,20}\b(research|search|web|look|dig|dive|investigate)|\b(research|search|web|look)\b[^\n]{0,15}\bdeep(ly)?\b|research\s+(it\s+|this\s+|that\s+)?(thorough|in[- ]depth|extensively)|in[- ]depth\s+(research|report|analysis)|thorough(ly)?\s+research|do\s+(some\s+|a\s+)?(proper\s+)?research|research\s+(on|about|into)\b|ডিপ\s*রিসার্চ|ডিপ(লি)?[^\n]{0,15}(রিসার্চ|সার্চ|ওয়েব|খুঁজ)|গভীর(ভাবে)?\s*(রিসার্চ|গবেষণা|অনুসন্ধান|সার্চ)|বিস্তারিত\s*(রিসার্চ|গবেষণা)|ভালো(ভাবে)?\s*(রিসার্চ|গবেষণা)|রিসার্চ\s*(করো|কর|করে)|গবেষণা\s*করো',
      caseSensitive: false);

  static final _web = RegExp(
      r'\b(search|google|look\s*up|browse|find)\b[^\n]{0,30}\b(web|online|internet|net|google)\b|\b(search|google)\s+(for|about|on)\b|\b(web|online|internet)\s+search\b|\bsearch\s+(it|this|that)\b|\b(latest|breaking|right now|up[- ]to[- ]date|this (week|month|year)|20(2[5-9]|3\d))\b|\b(news|weather|forecast|stock price|share price|exchange rate|live score|release date|price of|how much (is|does|are)|who won|who is the (current|new))\b|ওয়েব|ইন্টারনেট|অনলাইনে|গুগল|সার্চ|খুঁজে|সর্বশেষ|লেটেস্ট|আজকের|গতকাল|খবর|নিউজ|আবহাওয়া|স্কোর|দাম কত|রেট কত|বর্তমান',
      caseSensitive: false);

  static Intent detect(String t, {required bool imageModels}) {
    final s = t.trim();
    if (s.isEmpty || s.length > 1500) return Intent.chat;
    if (imageModels &&
        s.length < 500 &&
        !_howTo.hasMatch(s) &&
        (_imgEn.hasMatch(s) ||
            _imgEn2.hasMatch(s) ||
            _imgBn.hasMatch(s) ||
            _imgBl.hasMatch(s))) {
      return Intent.image;
    }
    if (_deep.hasMatch(s)) return Intent.deep;
    if (_web.hasMatch(s)) return Intent.web;
    return Intent.chat;
  }
}
